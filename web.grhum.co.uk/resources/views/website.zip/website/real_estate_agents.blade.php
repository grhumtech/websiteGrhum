{{-- resources/views/website/real_estate_agents.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Real Estate Agents | Grhum</title>
</head>
<body>
  <h1>Real Estate Agents</h1>
  {{-- TODO: port the HTML body from your legacy CI view here. --}}
</body>
</html>
