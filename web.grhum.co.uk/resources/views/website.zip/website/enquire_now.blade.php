{{-- resources/views/website/enquire_now.blade.php --}}
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Enquire Now | Grhum</title></head>
<body>
  <h1>Enquire Now</h1>
  <p>No matching properties were found. <a href="{{ url('website/enquire_now_new') }}">Send us an enquiry instead &rarr;</a></p>
</body></html>
