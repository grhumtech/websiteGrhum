{{-- resources/views/website/about_us.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>About Us | Grhum</title>
</head>
<body>
  <h1>About Us</h1>
  {{-- TODO: port the HTML body from your legacy CI view here. --}}
</body>
</html>
