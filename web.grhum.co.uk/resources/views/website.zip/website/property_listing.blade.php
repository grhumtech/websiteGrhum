{{-- resources/views/website/property_listing.blade.php --}}
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Properties | Grhum</title></head>
<body>
  <h1>Available Properties</h1>
  <div class="property-grid">
    @forelse($data ?? [] as $p)
      <div class="property-card">
        <h3>{{ $p->property_name ?? $p->title ?? ('Property #'.$p->property_id) }}</h3>
        <p>{{ $p->address ?? '' }}</p>
        <a href="{{ url('website/propertyDetail/'.$p->property_id) }}">View details</a>
      </div>
    @empty
      <p>No properties found.</p>
    @endforelse
  </div>
</body></html>
