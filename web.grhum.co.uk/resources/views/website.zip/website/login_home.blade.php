{{-- resources/views/website/login_home.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>Grhum</title></head>
<body>
  <h1>Welcome to Grhum</h1>
  <h3>Locations</h3>
  <ul>
    @forelse($location ?? [] as $loc)
      <li>{{ $loc->name ?? $loc->location_name ?? '' }}</li>
    @empty
      <li>No locations found.</li>
    @endforelse
  </ul>
</body>
</html>
