{{-- resources/views/website/accreditations_partnerships.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Accreditations & Partnerships | Grhum</title>
</head>
<body>
  <h1>Accreditations & Partnerships</h1>
  {{-- TODO: port the HTML body from your legacy CI view here. --}}
</body>
</html>
