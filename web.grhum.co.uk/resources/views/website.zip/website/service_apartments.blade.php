{{-- resources/views/website/service_apartments.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Service Apartments | Grhum</title>
</head>
<body>
  <h1>Service Apartments</h1>
  {{-- TODO: port the HTML body from your legacy CI view here. --}}
</body>
</html>
