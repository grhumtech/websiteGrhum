{{-- resources/views/website/property_management_companies.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Property Management Companies | Grhum</title>
</head>
<body>
  <h1>Property Management Companies</h1>
  {{-- TODO: port the HTML body from your legacy CI view here. --}}
</body>
</html>
