{{-- resources/views/website/film_production.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Film Production | Grhum</title>
</head>
<body>
  <h1>Film Production</h1>
  {{-- TODO: port the HTML body from your legacy CI view here. --}}
</body>
</html>
