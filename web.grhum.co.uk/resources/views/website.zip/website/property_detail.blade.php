{{-- resources/views/website/property_detail.blade.php --}}
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Property Detail | Grhum</title></head>
<body>
  @php $p = ($data[0] ?? null); @endphp
  <h1>{{ $p->property_name ?? $p->title ?? ('Property #'.($p->property_id ?? '')) }}</h1>
  <p>{{ $p->address ?? '' }}</p>

  <h3>Images</h3>
  @foreach($image ?? [] as $img)
    <img src="{{ $img->image ?? '' }}" alt="" style="max-width:200px;">
  @endforeach

  <h3>Amenities</h3>
  <ul>@foreach($aminities ?? [] as $a)<li>{{ $a->aminity_name ?? $a->name ?? '' }}</li>@endforeach</ul>

  <h3>Neighborhood</h3>
  <ul>@foreach($neighborhood ?? [] as $n)<li>{{ $n->name ?? '' }}</li>@endforeach</ul>

  <h3>Terms</h3>
  <ul>@foreach($terms ?? [] as $t)<li>{{ $t->term_name ?? $t->name ?? '' }}</li>@endforeach</ul>
</body></html>
