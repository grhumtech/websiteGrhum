{{-- resources/views/website/locations.blade.php --}}
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Locations | Grhum</title></head>
<body>
  <h1>Locations</h1>
  <ul>
    @forelse($location ?? [] as $loc)
      <li>{{ $loc->name ?? $loc->location_name ?? '' }}</li>
    @empty
      <li>No locations found.</li>
    @endforelse
  </ul>
</body></html>
